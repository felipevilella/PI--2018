<?php
 class Chat_model extends CI_Controller{
 	
 	function__construct(){
 		$this->load->database();
 	}
	public function pesquisar($usuario,$destinario){
		$this->db->join ("mensagem","fk_Mensagem = idMensagem");
		$this->db->where("idUsuario",$usuario);
		$this->db->where("idDestinatario",$destinario);
		return $this->db->get("conversa")->result_array();
 	}

 }

 