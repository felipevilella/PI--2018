<br><br><br>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col-md-4">
							<h4>Bairro</h4>
							<div class="form-check form-check-radio">
								<label class="form-check-label">
									<input class="form-check-input" type="radio" name="Bairro" id="exampleRadios1" value="option1" >
									Barro Preto
									<span class="circle">
										<span class="check"></span>
									</span>
								</label>
							</div>
							<div class="form-check form-check-radio">
								<label class="form-check-label">
									<input class="form-check-input" type="radio" name="Bairro" id="exampleRadios2" value="option2" checked>
									Carlos Prates
									<span class="circle">
										<span class="check"></span>
									</span>
								</label>
							</div>

							<div class="form-check form-check-radio disabled">
								<label class="form-check-label">
									<input class="form-check-input" type="radio" name="Bairro" id="exampleRadios1" value="option1" >
									Savassi
									<span class="circle">
										<span class="check"></span>
									</span>
								</label>
							</div>
							<h4>Idade</h4>
							<div class="form-check form-check-radio">
								<label class="form-check-label">
									<input class="form-check-input" type="radio" name="Idade" id="exampleRadios1" value="option1" >
									Filhote
									<span class="circle">
										<span class="check"></span>
									</span>
								</label>
							</div>
							<div class="form-check form-check-radio">
								<label class="form-check-label">
									<input class="form-check-input" type="radio" name="Idade" id="exampleRadios2" value="option2" checked>
									Adulto
									<span class="circle">
										<span class="check"></span>
									</span>
								</label>
							</div>

							<div class="form-check form-check-radio disabled">
								<label class="form-check-label">
									<input class="form-check-input" type="radio" name="Idade" id="exampleRadios1" value="option1" >
									Idoso
									<span class="circle">
										<span class="check"></span>
									</span>
								</label>
							</div>
						</div>
						<div class="row">
							<div class="col-md-2">
								<a href="#"><i class="material-icons">keyboard_arrow_left</i><br>Anterior<br></a>
							</div>
							<div class="col-md-8">
								<center><h3>Mel</h3></center>
								<img  src="<?php echo base_url('assets/personalizado/imagem/cachoro.png');?>" width="100%">
								<br><br>
								<div class="foto1">
									<img  src="<?php echo base_url('assets/personalizado/imagem/avatar.jpg');?>"  >
								</div>
								<a href=""><i class="material-icons">done</i>Solicitar encontro</a>&nbsp&nbsp&nbsp
								<a href=""><i class="material-icons">highlight_off</i>Não solicitar encontro</a>
							</div>
							<div class="col-md-2">
								<a href="#"><i class="material-icons">keyboard_arrow_right</i><br>Proximo</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

</div>
</div>