<br><br>
<br><br>
  <div class="container">
  <div class="row">
  <div class="col-md-3">
  </div>
<div class="col-md-6 card card-nav-tabs"" >

    <div class="card-success">
      <div class="form-group label-floating has-warning">
        <div class="container">
          <div class="row">
            <div class="col-md-12"><h3><center><font color="black">Crie sua nova conta</font></center></h3></div>
            <div class="col-md-6">
              <label><font color="black">Nome</font></label><br>
              <input type="text" class="form-control"  placeholder="" id="nome" >
            </div>
            <div class="col-md-6">
              <label><font color="black">Sobrenome</font></label><br>
              <input type="text" class="form-control"  placeholder="" id="sobrenome" >
            </div>
            <div class="col-md-6">
              <label><font color="black">Estado</font></label><br>
              <select id="inputState" class="form-control">
                <option selected>Selecione uma opção</option>
                <option value="1">Minas Gerais</option>
                <option value="2">São Paulo</option>
                <option value="3">Rio de Janeiro</option>              </select>
              </div>
              <div class="col-md-6">
                <label><font color="black">Cidade</font></label><br>
                <select id="inputState" class="form-control">
                  <option selected>Selecione uma opção</option>
                  <option value="1">Belo Horizonte</option>
                  <option value="2">São Paulo</option>
                  <option value="3">Rio de Janeiro</option>
                </select>
              </div>
              <div class="col-md-12">
                <label><font color="black">Email</font></label><br>
                <input type="text" class="form-control"  placeholder="" id="email" >
              </div>
              <div class="col-md-12">
                <label><font color="black">Senha</font></label><br>
                <input type="password" class="form-control"  placeholder="" id="password" >
              </div>
              <div class="col-md-12">
                <label><font color="black">Confirmação de senha</font></label><br>
                <input type="password" class="form-control"  placeholder="" id="password1" >
              </div>
              <div class="col-md-4">
                <br>
                 <button class="btn btn-warning" type="submit" name="action">Cadastrar </button>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

