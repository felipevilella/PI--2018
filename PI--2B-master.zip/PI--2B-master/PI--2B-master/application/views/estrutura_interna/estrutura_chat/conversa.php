<div class="msg_history">
<?php 


}
?>
<?php foreach ($conversa as $key=> $conversa) : ?:>
            <div class="incoming_msg">
              <div class="incoming_msg_img fotocompleto" > <img src="<?php echo ('assets/personalizado/imagem/avatar.jpg');?>" > </div>
              <div class="received_msg">
                <div class="received_withd_msg">
				<?php if($conversa["idusuario"] == $idusuario){ ?>
                  <p>Ola tudo bem?</p>
                  <span class="time_date"> 11:01 AM    |    Out 10</span></div>
              </div>
            </div>
            <div class="outgoing_msg">
              <div class="sent_msg">
                <p>Sim e vc?</p>
                <span class="time_date"> 11:01 AM    |    Out 10</span> </div>
            </div>
          </div>
          <label id="retorno"></label>
          <div class="type_msg">
            <div class="input_msg_write">
              <input type="text"  id="campochat" class="write_msg" placeholder="Digite uma mensagem" />
              <button class="msg_send_btn" type="button"><i class="fa fa-paper-plane-o" aria-hidden="true"></i></button>
            </div>
</div>
<?end foreach>