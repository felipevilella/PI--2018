<div class="inbox_people">
          <div class="headind_srch">
            <div class="recent_heading">
              <h4>Recentes</h4>
            </div>
            <div class="srch_bar">
              <div class="stylish-input-group">
                <input type="text" class="search-bar"  placeholder="Pesquisar" >
                <span class="input-group-addon">
                <button type="button"> <i class="fa fa-search" aria-hidden="true"></i> </button>
                </span> </div>
            </div>
          </div>
          <div class="inbox_chat">
            <div class="chat_list active_chat">
              <div class="chat_people">
                <div class="chat_img fotocompleto"> <img src="<?php echo ('assets/personalizado/imagem/avatar.jpg');?>" > </div>
                <div class="chat_ib">
                  <h5>Mirian <span class="chat_date">Out 10</span></h5>
                  <p> Sim e vc?</p>
                </div>
              </div>
            </div>
            <div class="chat_list">
              <div class="chat_people">
                <div class="chat_img fotocompleto"> <img src="<?php echo ('assets/personalizado/imagem/card-profile2-square.jpg');?>" > </div>
                <div class="chat_ib">
                  <h5>Pedro <span class="chat_date">Out 19</span></h5>
                  <p>Vamos caminhar juntos e o Thor esta com saudade da Mel .</p>
                </div>
              </div>
            </div>
            <div class="chat_list">
              <div class="chat_people">
                <div class="chat_img fotocompleto"> <img src="<?php echo ('assets/personalizado/imagem/avatar.jpg');?>" > </div>
                <div class="chat_ib">
                  <h5>Bianca <span class="chat_date">Out 21</span></h5>
                  <p>Qual o endereço da clinica veterinaria que você levou a Mel ?</p>
                </div>
              </div>
            </div>
           
          </div>
        </div>