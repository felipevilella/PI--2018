<br><br><br><br>
<div class="container">
<div class="messaging">
      <div class="inbox_msg">
        <? php $this ->load -> view('ultimasconversas');?>
        <div class="mesgs">
          <? php $this ->load -> view('conversaSelecionada');?>
        </div>
      </div>
      
</div></div>