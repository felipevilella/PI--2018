<br><br><br><br><br><br><br><br>
<div class="container">
  <div class="row">
   <div class="col-lg-4 col-md-6 col-sm-6 ml-auto mr-auto ">
    <div class="card card-nav-tabs">
      <div class="card-header card-header-warning">
        Acesso
      </div>
      <div class="card-body">
        <label id="retorno"></label><br>
        <label>E-mail</label>
        <input type="email" class="form-control" id="email" name="email">
        <label>Senha</label>
        <input type="password" class="form-control" id="senha" name="senha">
        <a href="#" id="esqueci">Esqueci ou nao tenho a senha</a><br><br>

        <input type="" id = "Entrar" value="Entrar" class="btn btn-warning">
      </div>

    </div>
  </div>
</div>
</div>
