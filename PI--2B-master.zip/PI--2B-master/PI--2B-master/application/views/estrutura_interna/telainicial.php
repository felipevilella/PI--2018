<br><br><br>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<div class="container">
  <div class="row">
   <div class="col-lg-10 col-md-12 col-sm-12 ml-auto mr-auto " align = "center">
		<br><br><br><br><br><br><br><br><br>
		<h1 style="color:#FFD700; font-family:cursive, sans-serif"> PET'S MEETING</h1>
		<br>
		<hr style="height:2px; border:none; color:#FFD700; background-color:#FFD700; margin-top: 0px; margin-bottom: 0px;"/><br>
		<h5 style="color:#FFD700;font-family:cursive, sans-serif">Já pensou em encontrar um parceiro para o seu pet? Nós te ajudamos!</h5>
  </div>

</div>
</div>
  <br><br><br><br>