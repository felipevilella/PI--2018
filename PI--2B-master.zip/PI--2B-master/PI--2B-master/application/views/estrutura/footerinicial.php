<br><br><br>
 <footer class="footer" >
    <div class="container">
      
        <div class="copyright float-right">
        	<font color="white">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>, 
            </font>
          <font color="white"> Pets Meetings</font>.
        </div>
    </div>
</footer>



  <script src="<?php echo base_url('assets/bootstrap/js/core/jquery.min.js');?>" type="text/javascript"></script>
  <script src="<?php echo base_url('assets/bootstrap/js/core/popper.min.js');?>" type="text/javascript"></script>
  <script src="<?php echo base_url('assets/bootstrap/js/core/bootstrap-material-design.min.js');?>" type="text/javascript"></script>
  <script src="<?php echo base_url('assets/bootstrap/js/plugins/perfect-scrollbar.jquery.min.js')?>"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <script src="<?php echo base_url('assets/bootstrap/js/plugins/chartist.min.js')?>"></script>
  <script src="<?php echo base_url('assets/bootstrap/js/plugins/bootstrap-notify.js');?>"></script>
  <script src="<?php echo base_url('assets/bootstrap/js/material-dashboard.min.js?v=2.1.0');?>" type="text/javascript"></script>
  <script src="<?php echo base_url('assets/personalizado/js/sistema.js');?>"></script>
 
    <script src="<?php echo base_url('assets/personalizado/js/tabs.js');?>"></script>
  <script>
    $(document).ready(function() {
      md.initDashboardPageCharts();

    });
  </script>

  <script type="text/javascript">
    var base_url = "<?php echo base_url();?>";
</script>

</body>

</html>